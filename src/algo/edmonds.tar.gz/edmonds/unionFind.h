#include "vertex.h"

void unionvx(Vertex *, Vertex *);
Vertex* findvx(Vertex *);

