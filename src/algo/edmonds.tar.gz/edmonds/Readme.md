1. make all
2. ./edmonds -> Input/Output format will appear on the console
